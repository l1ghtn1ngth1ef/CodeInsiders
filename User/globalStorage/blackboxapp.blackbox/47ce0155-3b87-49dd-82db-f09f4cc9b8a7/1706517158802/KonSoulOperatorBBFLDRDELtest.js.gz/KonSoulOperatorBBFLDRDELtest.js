const array = ['1', '2', '3', '4', '5'];
/* eslint-disable */

const msg = console.log("Running ...", "\n")
/*
for (i = 0; i <= array.length; i++) {
    console.log(`${[i]}`);
}
*/
const newFunction = array.map((callbackPlaceHolder) => console.log(callbackPlaceHolder));

const Prim = new Promise((resolve, reject) => resolve("Promise Complete"))

const object = {
    name: 'SpongeBob',
}

console.log(object)

const obj = {

    name: "key1",
    method: new Promise((resolve, reject) => console.log(resolve("Promises!")))

}

console.log(obj);

